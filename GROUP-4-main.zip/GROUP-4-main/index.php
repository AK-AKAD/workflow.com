<?php
header("Content-Type: application/json");

include 'login.php';
include 'db.php';

if($_SERVER['REQUEST_METHOD'] == 'GET'){
    if(isset($_GET['info'])){
        
        if($_GET['info'] == 'index'){
            $events = getEvents($pdo, $_GET['email']);
            $announce = getAnnounce($pdo, $_GET['email']);

            $info = array($events, $announce);
            echo json_encode($info);

            //projects the users email is listed under
           // getProjects($pdo, $_GET['email']);
    
        }elseif($_GET['info'] == 'firstname'){
            try{

                $stmt = $pdo->prepare("SELECT firstName FROM userTable WHERE email = ?");
                $stmt->bindParam(1, $_GET['email']);
        
                $stmt->execute();
                $results = $stmt->fetchColumn();
        
                if ($results) {
                    // $resultName = $results['firstName'];
                    echo json_encode("success:name:".$results);
                } else {
                    echo json_encode("get firstname: No results found for ". $_POST['email']);
                }
            }catch(PDOException $e){
                $e->getMessage();
                echo json_encode("get firstname: ".$e);
            }
        }elseif($_GET['info'] == 'messages'){
            try{

                //get all messages sent from and recieved by the specific user
                $stmt = $pdo->prepare("SELECT* FROM messages WHERE sender = ? OR reciever = ? ");
                $stmt->bindParam(1, $_GET['email']);
                $stmt->bindParam(2, $_GET['email']);
    
                $stmt->execute();
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode($results);
                
                /*
                if (count($results) > 0) {
                    $sentMSG = implode("\n", array_map(function($row) {
                    return "sender: ".$row['sender']."\n"."reciever: ".$row['reciever']."\n"."msg: ".$row['message'];
                    }, $results));
    
                    echo json_encode($sentMSG);
                } else {
                    echo json_encode("No results found");
                }
                
                */
            }catch(PDOException $e){
                $e->getMessage();
                echo json_encode("messages: ".$e);
            }
        }elseif($_GET['info'] == 'getAllUsers'){
            $users = getAllUsers($pdo);
            echo json_encode($users);

        }elseif($_GET['info'] == 'tasks'){

            getTasks($pdo, $_GET['email']);
        }elseif($_GET['info'] == 'events'){

            getEvents($pdo, $_GET['email']);
        }elseif($_GET['info'] == 'announcements'){

            getAnnounce($pdo, $_GET['email']);
        }
    }
    
}

function getTasks($pdo, $email){
    try{

        // get all tasks concerning the specific user
        $stmt = $pdo->prepare("SELECT* FROM prjInfo WHERE users = ? AND typeofInfo = task");
        $stmt->bindParam(1, $email);
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if(count($results) > 0){
            $result = implode("\n", array_map(function($row) {
                return $row[4];
            }, $results));

            echo json_encode($result);
        }else{
            echo json_encode("getTasks: No results found");
        }
        
    }catch(PDOExcpetion $e){
        $e->getMessage();
        echo json_encode("getTasks: ".$e);
    }
}
    
function getAnnounce($pdo, $email){
    try{

        //get all announcements
        $stmt = $pdo->prepare("SELECT* FROM prjInfo where users = ? AND typeofInfo = 'announcement'");
        $stmt->bindParam(1, $email);

        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if(count($result) > 0){
            return $result['task'];
        }else{
            return ("getAnnounce: No results found");
        }
    }catch(PDOException $e){
        $e->getMessage();
        echo json_encode("getAnnounce: ".$e);
    }
}

function getEvents($pdo, $email){
    try{

        //get events concerning the specific user
        $stmt = $pdo->prepare("SELECT* FROM events WHERE email = ?");
        $stmt->bindParam(1, $email);
    
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if(count($result) > 0){

            return $result['eventName'];
        }else{
            return ("getEvents: No results found");
        }
    
    }catch(PDOException $e){
        $e->getMessage();
        echo json_encode("getEvents: ".$e);
    }
}

function getProjects($pdo, $email){
    try{

        $stmt = $pdo->prepare('SELECT projects FROM prjts WHERE users = ?');
        $stmt->bindParam(1, $email);
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if(count($results) >1){
            $recievedMSG = implode("\n", array_map(function($row){
                return implode(",", $row);
            }, $results));

            echo json_encode($recievedMSG);
        }else{
            echo json_encode("getProjects: No results found");
        }
    }catch(PDOException $e){
        $e->getMessage();
        echo json_encode("getProjects: ".$e);
    }
}

function getAllUsers($pdo){
    try{

        $stmt = $pdo->prepare('SELECT* FROM userTable');
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;

    }catch(PDOException $e){
        $e->getMessage();
        echo json_encode("getAllUsers: ".$e);
    }
}