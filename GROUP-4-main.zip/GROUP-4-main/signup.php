<?php
include 'db.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){

    if(empty($_POST["firstName"])){
        echo json_encode("empty-field: firstName");

    }elseif(empty($_POST["lastName"])){
        echo json_encode("empty-field: lastName");

    }elseif(empty($_POST["email"])){
        echo json_encode("empty-field: email");

    }elseif(empty($_POST["passw"])){
        echo json_encode("empty-field: password");

    }elseif(empty($_POST["Cpassw"])){
        echo json_encode("empty-field: confirm password");

    }elseif($_POST["passw"] != $_POST["Cpassw"]){
        echo json_encode("pass-noMatch");

    }else{
        signup($pdo, $_POST["firstName"], $_POST["lastName"], $_POST["email"], $_POST["passw"]);
    }
}

function signup($pdo, $firstName, $lastName, $email, $Upassw){
    try{
        $stmt = $pdo->prepare("INSERT INTO userTable (firstName, lastName, email, passw) VALUES(?, ?, ?, ?)");
        $stmt->bindParam(1, $firstName);
        $stmt->bindParam(2, $lastName);
        $stmt->bindParam(3, $email);
        $stmt->bindParam(4, $Upassw);

        $stmt->execute();
        echo json_encode("success");

    }catch(PDOException $e){
        $e->getMessage();
        echo json_encode("Signup error: ".$e);
    }
    
}
