<?php
header("Content-Type: application/json");
include 'db.php';

if($_SERVER['REQUEST_METHOD'] === 'GET'){

    if($_GET['info'] === 'info'){
        $stmt = $pdo->prepare("SELECT* FROM userTable WHERE email = ?");
        $stmt->bindParam(1, $_GET['users']);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($result);
    }
}