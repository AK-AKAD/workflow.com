var param = new URLSearchParams(window.location.search);
var user = param.get("user");

document.addEventListener("DOMContentLoaded", function(){

    try{
        $.ajax({
            type: "GET",
            url: "profile.php",
            data:{
                info: 'info',
                users : user
            },
            dataType: "Json",
            success: function(response){
                // console.log(response[0]['firstName']);
                info(response[0]['firstName'], response[0]['email']);
            },
            error: function(status, error){
                console.error("AJAX Error: ", status, error);
            }
        });

    }catch(error){
        console.error(error);
    }
})

function info(firstName, email){
    let name = document.getElementById('name-container');
    let nameValue = document.createElement('div');
    name.appendChild(nameValue);

    const nameValueContent = `<label for="name">Name</label>
                            <input type="text" id="name" name="name" value="`+firstName+`">`;

    nameValue.innerHTML = nameValueContent;

    let Useremail = document.getElementById('email-container');
    let emailValue = document.createElement('div');
    Useremail.appendChild(emailValue);

    const emailValueContent = `<label for="email">email</label>
                            <input type="text" id="email" name="email" value="`+email+`">`;

    emailValue.innerHTML = emailValueContent;
}


function loadFile(event) {
    var output = document.getElementById('profilePic');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
        URL.revokeObjectURL(output.src) // free memory
    }
}
