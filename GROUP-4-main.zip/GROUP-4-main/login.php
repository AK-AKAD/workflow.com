<?php
include 'db.php';
header("Content-Type: application/json");


if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(isset($_POST['info'])){

        if(empty($_POST['email'])){
            echo json_encode("empty-field: email");

        }elseif(empty($_POST['passw'])){
            echo json_encode("empty-field: passw");

        }else{
            validate($pdo, $_POST['email'], $_POST['passw']);
        }
        
    }
}

function validate($pdo, $email, $passw){
    try{
       
        $stmt = $pdo->prepare("SELECT * FROM userTable WHERE email = ? AND passw = ?");
        $stmt->bindParam(1, $email);
        $stmt->bindParam(2, $passw);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if(count($result)>0){
            echo json_encode("success");
        }else{
            echo json_encode("invalid login");
        }

    }catch(PDOException $e){
        $e->getMessage();
        echo json_encode($e);
    }
}