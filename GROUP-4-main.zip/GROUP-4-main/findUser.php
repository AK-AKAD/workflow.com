<?php

include 'db.php';

if($_SERVER['REQUEST_METHOD'] === 'GET'){

    if($_GET['action'] == 'find'){

        findUser($pdo, $_GET['user']);

    }elseif($_GET['action'] == 'list'){

        list($pdo);
    }
}

function findUser($pdo, $user){

    try{
        $stmt = $pdo->prepare('SELECT* FROM userTable WHERE firstName OR lastName LIKE ? ');
        $stmt -> bindParam(1, $user);

        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($results) > 0) {
            $resultsString = implode("\n", array_map(function($row) {
                echo json_encode(implode(",", $row));
            }, $results));
        }else{
            echo json_encode("User was not found");
        }
    }catch(PDOException $e){
        $e->getMessage();
        echo json_encode($e);
    }
}

function list($pdo){
// list all users registered
    try{
        $stmt = $pdo->prepare('SELECT* FROM userTable');
        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($results) > 0) {
            $resultsString = implode("\n", array_map(function($row) {
                echo json_encode(implode(",", $row));
            }, $results));
        }else{
            echo json_encode("User was not found");
        }
    }catch(PDOException $e){
        $e->getMessage();
        echo $e;
    }
}